package week05d04;

public enum Currency {

    HUF, USD, EUR
}
